package com.farmer.farmerservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmerservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
