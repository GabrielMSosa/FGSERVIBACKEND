package com.farmer.farmerservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmerservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmerservicesApplication.class, args);
	}

}
