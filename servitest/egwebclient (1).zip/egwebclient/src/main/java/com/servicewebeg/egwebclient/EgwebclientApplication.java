package com.servicewebeg.egwebclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EgwebclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(EgwebclientApplication.class, args);
	}

}
