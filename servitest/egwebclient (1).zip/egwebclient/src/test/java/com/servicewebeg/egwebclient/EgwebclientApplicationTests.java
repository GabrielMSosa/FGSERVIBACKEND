package com.servicewebeg.egwebclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EgwebclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
