package com.providerinfo.providerinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProviderinfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProviderinfoApplication.class, args);
	}

}
