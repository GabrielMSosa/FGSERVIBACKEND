package com.pandoracenter.pandora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PandoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(PandoraApplication.class, args);
	}

}
