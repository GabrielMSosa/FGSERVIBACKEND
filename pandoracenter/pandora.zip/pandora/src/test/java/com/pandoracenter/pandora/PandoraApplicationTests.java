package com.pandoracenter.pandora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PandoraApplicationTests {

	@Test
	void contextLoads() {
	}

}
