package com.pandora.checkinfarmer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CheckinfarmerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CheckinfarmerApplication.class, args);
	}

}
