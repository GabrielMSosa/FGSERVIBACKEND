package com.frontend.msvcfrontend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsvcFrontendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsvcFrontendApplication.class, args);
	}

}
