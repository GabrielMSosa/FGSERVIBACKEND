package com.frontend.msvcfrontend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcFrontendApplicationTests {

	@Test
	void contextLoads() {
	}

}
